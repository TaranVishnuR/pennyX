import { Link, useNavigate } from "react-router-dom";
import { auth, logoutUser, onAuthStateChanged } from "../firebaseConfig";
import { useEffect, useState } from "react";
import { logoutUser } from "../firebaseConfig.js";

const Navbar = () => {
    const [user, setUser] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        onAuthStateChanged(auth, (currentUser) => {
            setUser(currentUser);
        });
    }, []);

    const handleLogout = async () => {
        await logoutUser();
        navigate("/login");
    };

    return (
        <nav>
            <h1>PennyX</h1>
            <p className="slogan">"Every note makes a count."</p>
            <div>
                <Link to="/">Home</Link>
                <Link to="/transactions">Transactions</Link>
                <Link to="/reports">Reports</Link>
                <Link to="/monthly-reports">Monthly Reports</Link>
                {!user ? (
                    <>
                        <Link to="/signup">Sign Up</Link>
                        <Link to="/login">Login</Link>
                    </>
                ) : (
                    <button onClick={handleLogout} className="logout-btn" title="Logout">Logout</button>
                )}
            </div>
        </nav>
    );
};

export default Navbar;
