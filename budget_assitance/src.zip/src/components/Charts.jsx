import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend } from "recharts";

const Charts = ({ expenses }) => {
    if (expenses.length === 0) {
        return <p className="chart-message">No expense data available for charts.</p>;
    }

    // 📊 Group Expenses by Category for Pie Chart
    const categoryTotals = expenses.reduce((acc, expense) => {
        acc[expense.category] = (acc[expense.category] || 0) + expense.amount;
        return acc;
    }, {});

    const categoryData = Object.keys(categoryTotals).map(category => ({
        name: category,
        value: categoryTotals[category],
    }));

    // 📉 Group Expenses by Month for Bar Chart
    const monthTotals = expenses.reduce((acc, expense) => {
        const month = new Date(expense.date).toLocaleString("default", { month: "short", year: "numeric" });
        acc[month] = (acc[month] || 0) + expense.amount;
        return acc;
    }, {});

    const monthData = Object.keys(monthTotals).map(month => ({
        month,
        total: monthTotals[month],
    }));

    const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#A28EF0", "#E84C3D"];

    return (
        <div className="chart-container">
            <h2>Expense Analysis</h2>

            {/* 📊 Pie Chart (Expense Distribution) */}
            <div className="chart-box">
                <h3>Expenses by Category</h3>
                <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                        <Pie data={categoryData} cx="50%" cy="50%" outerRadius={100} fill="#8884d8" label>
                            {categoryData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                        </Pie>
                        <Tooltip />
                    </PieChart>
                </ResponsiveContainer>
            </div>

            {/* 📉 Bar Chart (Monthly Spending) */}
            <div className="chart-box">
                <h3>Monthly Spending</h3>
                <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={monthData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="total" fill="#3498db" />
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </div>
    );
};

export default Charts;
