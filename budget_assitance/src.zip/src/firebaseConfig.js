import { initializeApp } from "firebase/app";
import { getAuth, signOut, onAuthStateChanged } from "firebase/auth";
import { getFirestore, collection, addDoc, onSnapshot, query, where } from "firebase/firestore";

// Firebase configuration

// Firebase configuration
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_AUTH_DOMAIN",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// ✅ Function to Log Out User
export const logoutUser = async () => {
    try {
        await signOut(auth);
        console.log("✅ User Logged Out");
    } catch (error) {
        console.error("❌ Logout Error:", error);
    }
};

// ✅ Export Firebase Modules
export { auth, db, onAuthStateChanged };