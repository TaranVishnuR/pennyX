import { useState, useEffect } from "react";
import { db } from "../firebaseConfig";
import { collection, getDocs, deleteDoc, doc } from "firebase/firestore";

const Transactions = () => {
    const [transactions, setTransactions] = useState([]);

    useEffect(() => {
        const fetchTransactions = async () => {
            const querySnapshot = await getDocs(collection(db, "transactions"));
            const transactionsList = querySnapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data()
            }));
            setTransactions(transactionsList);
        };

        fetchTransactions();
    }, []);

    const handleDelete = async (id) => {
        await deleteDoc(doc(db, "transactions", id));
        setTransactions(transactions.filter(txn => txn.id !== id));
    };

    return (
        <div className="card">
            <h2>All Transactions</h2>
            {transactions.length === 0 ? <p>No transactions found.</p> : (
                <ul>
                    {transactions.map((txn) => (
                        <li key={txn.id}>
                            {txn.title} - ₹{txn.amount} ({txn.category}) on {new Date(txn.date).toLocaleDateString()}
                            <button className="delete-btn" onClick={() => handleDelete(txn.id)}>❌</button>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
};

export default Transactions;
