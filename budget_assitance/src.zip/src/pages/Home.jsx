import { useState } from "react";
import { db } from "../firebaseConfig";
import { collection, addDoc, query, where, onSnapshot } from "firebase/firestore";
import { useAuth } from "../context/AuthContext";
import "../styles/Home.css";

const Home = () => {
    const { currentUser } = useAuth();
    const [budget, setBudget] = useState("");
    const [incomeList, setIncomeList] = useState([]);
    const [expenseList, setExpenseList] = useState([]);
    const [income, setIncome] = useState({ source: "", amount: "" });
    const [expense, setExpense] = useState({ title: "", amount: "", category: "Groceries" });

    // Add Income
    const addIncome = async () => {
        if (!income.source || !income.amount) return;
        await addDoc(collection(db, "transactions"), {
            userId: currentUser?.uid,
            type: "income",
            title: income.source,
            amount: Number(income.amount),
            timestamp: new Date(),
        });
        setIncome({ source: "", amount: "" });
    };

    // Add Expense
    const addExpense = async () => {
        if (!expense.title || !expense.amount) return;
        await addDoc(collection(db, "transactions"), {
            userId: currentUser?.uid,
            type: "expense",
            title: expense.title,
            amount: Number(expense.amount),
            category: expense.category,
            timestamp: new Date(),
        });
        setExpense({ title: "", amount: "", category: "Groceries" });
    };

    return (
        <div className="home-container">
            <h1>Welcome {currentUser ? currentUser.email : "Guest"}</h1>
            <div className="budget-section">
                <h2>Set Monthly Budget</h2>
                <input type="number" placeholder="Enter Budget (₹)" value={budget} onChange={(e) => setBudget(e.target.value)} />
                <p>Current Budget: ₹{budget || 0}</p>
            </div>

            <div className="transaction-section">
                <h2>Add Income</h2>
                <input type="text" placeholder="Income Source" value={income.source} onChange={(e) => setIncome({ ...income, source: e.target.value })} />
                <input type="number" placeholder="Amount (₹)" value={income.amount} onChange={(e) => setIncome({ ...income, amount: e.target.value })} />
                <button onClick={addIncome}>Add Income</button>
            </div>

            <div className="transaction-section">
                <h2>Add Expense</h2>
                <input type="text" placeholder="Expense Title" value={expense.title} onChange={(e) => setExpense({ ...expense, title: e.target.value })} />
                <input type="number" placeholder="Amount (₹)" value={expense.amount} onChange={(e) => setExpense({ ...expense, amount: e.target.value })} />
                <button onClick={addExpense}>Add Expense</button>
            </div>
        </div>
    );
};

export default Home;
