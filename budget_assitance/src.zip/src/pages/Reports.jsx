import { useEffect, useState } from "react";
import { collection, query, where, onSnapshot } from "firebase/firestore";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { useAuth } from "../context/AuthContext";
import { db } from "../firebaseConfig";
import "../styles/Reports.css";

const Reports = () => {
    const { currentUser } = useAuth();
    const [transactions, setTransactions] = useState([]);

    useEffect(() => {
        if (!currentUser) return;

        const q = query(collection(db, "transactions"), where("userId", "==", currentUser.uid));
        const unsubscribe = onSnapshot(q, (snapshot) => {
            const transactionsData = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
            setTransactions(transactionsData);
        });

        return () => unsubscribe();
    }, [currentUser]);

    return (
        <div className="reports-container">
            <h1>Monthly Reports</h1>
            <h2>Summary</h2>
            <ResponsiveContainer width="100%" height={300}>
                <BarChart data={transactions}>
                    <XAxis dataKey="title" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="amount" fill="#4CAF50" />
                </BarChart>
            </ResponsiveContainer>
        </div>
    );
};

export default Reports;
