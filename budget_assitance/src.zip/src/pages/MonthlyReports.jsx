import { useState, useEffect } from "react";
import Charts from "../components/Charts";

const MonthlyReports = () => {
    const [expenses, setExpenses] = useState([]);

    // Load expenses from localStorage
    useEffect(() => {
        const savedExpenses = localStorage.getItem("expenses");
        if (savedExpenses) {
            setExpenses(JSON.parse(savedExpenses));
        }
    }, []);

    return (
        <div className="monthly-report">
            <h1>Monthly Expense Reports</h1>
            {expenses.length === 0 ? (
                <p>No expense data available.</p>
            ) : (
                <Charts expenses={expenses} />
            )}
        </div>
    );
};

export default MonthlyReports;
